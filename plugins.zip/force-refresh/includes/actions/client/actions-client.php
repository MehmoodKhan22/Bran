<?php
/**
 * All of our actions for visitors to our site.
 *
 * @package ForceRefresh
 */

namespace JordanLeven\Plugins\ForceRefresh;

require_once __DIR__ . '/inc.refresh-js.php';
